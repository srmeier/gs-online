DISPLAY=:0 ./adnet
