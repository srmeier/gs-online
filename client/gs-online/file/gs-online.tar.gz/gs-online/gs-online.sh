#!/bin/bash

./adnet
